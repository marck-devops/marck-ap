export const content = [
    {
        name: "All",
        content: "all"
    },
    {
        name: "Translate",
        content: "translate"
    },
    {
        name: "Orignal",
        content: "original"
    },
    {
        name: "MTl (Machine Translate)",
        content: "mtl"
    },
]

export const status = [
    {
        name: "All",
        status: "all"
    },
    {
        name: "Completed",
        status: "completed"
    },
    {
        name: "Ongoing",
        status: "ongoing"
    },
]

export const categories = [
    {
        name: "All",
        genre: "all",
    },
    {
        name: "Urban",
        genre: "urban",
    },
    {
        name: "Eastern",
        genre: "eastern",
    },
    {
        name: "Games",
        genre: "games",
    },
    {
        name: "Fantasy",
        genre: "fantasy",
    },
    {
        name: "Sci-fi",
        genre: "sci-fi",
    },
    {
        name: "Horror",
        genre: "horror",
    },
    {
        name: "Sports",
        genre: "sports",
    },
    {
        name: "Action",
        genre: "action",
    },
    {
        name: "War",
        genre: "war",
    },
    {
        name: "Realistic",
        genre: "realistic",
    },
    {
        name: "History",
        genre: "history",
    },
    {
        name: "ACG",
        genre: "acg",
    },
];
