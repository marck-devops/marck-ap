// export const baseUrl = "http://192.168.0.50:8002";
// export const baseUrl = "http://localhost:8002"
// export const baseUrl = "https://online-books-app.herokuapp.com"
export const baseUrl = "https://api.csnovels.com"
// export const baseUrl = "https://csnovels.com/api"
export const apiUrl = `${baseUrl}/api`;
export const imageUrl = `${baseUrl}/public/`