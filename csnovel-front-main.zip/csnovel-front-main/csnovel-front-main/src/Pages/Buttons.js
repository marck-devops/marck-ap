const Buttons=()=>{
    return(
        <>
            <div className="all_buttons mt-3">
    <div className="buttons">
    <button className="">NOVELS</button>
    <div className="fan_fic">
    <button className="">FAN-FIC</button>
    </div>
    <div className="comics">
    <button className="">COMICS</button>
    </div>      
    </div>
    </div>
        </>
    )
}
export default Buttons