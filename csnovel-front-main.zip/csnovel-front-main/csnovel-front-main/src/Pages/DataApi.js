// import AdoptedSoldier from "../Pictures/AdoptedSoldier.jpg"
// import LegendSoldier from "../Pictures/LegendSoldier.jpg"
// import CoreSoldier from "../Pictures/CoreSoldier.jpg"
// import AlmightySoldier from "../Pictures/AlmightySoldier.jpg"
// import SoldierEval from "../Pictures/SoldierEval.jpg"

// const DataApi=[
//     {
//         id:1,
//         imgsrc:AdoptedSoldier,
//         name:"adopted soldier",
//         category:"Magical Realism",
//         para:"4.45",
//         description:"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex iure quis quae sunt molestias impedit, amet adipisci fuga odit eius?"
//     },{
//         id:2,
//         imgsrc:LegendSoldier,
//         name:"legend of the supreme soldier",
//         category:"War & Military",
//         para:"4.28",
//         description:"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex iure quis quae sunt molestias impedit, amet adipisci fuga odit eius?"
//     },{
//         id:3,
//         imgsrc:CoreSoldier,
//         name:"core soldier",
//         category:"Martial Arts",
//         para:"4.6",
//         description:"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex iure quis quae sunt molestias impedit, amet adipisci fuga odit eius?"
//     },{
//         id:4,
//         imgsrc:AlmightySoldier,
//         name:"the almighty soldier",
//         category:"Romance",
//         para:"2.2",
//         description:"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex iure quis quae sunt molestias impedit, amet adipisci fuga odit eius?"
//     },{
//         id:5,
//         imgsrc:SoldierEval,
//         name:"soldier evaluation",
//         category:"Fantasy",
//         para:"1.2",
//         description:"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex iure quis quae sunt molestias impedit, amet adipisci fuga odit eius?"
//     }
// ]
// export default DataApi